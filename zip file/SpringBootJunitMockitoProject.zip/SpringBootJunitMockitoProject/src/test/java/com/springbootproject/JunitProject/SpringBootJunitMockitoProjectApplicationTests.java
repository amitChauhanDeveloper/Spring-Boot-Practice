package com.springbootproject.JunitProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJunitMockitoProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
