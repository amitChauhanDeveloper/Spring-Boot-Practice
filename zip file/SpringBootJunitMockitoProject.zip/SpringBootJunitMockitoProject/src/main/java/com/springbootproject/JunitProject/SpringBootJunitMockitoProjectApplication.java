package com.springbootproject.JunitProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJunitMockitoProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJunitMockitoProjectApplication.class, args);
	}

}
