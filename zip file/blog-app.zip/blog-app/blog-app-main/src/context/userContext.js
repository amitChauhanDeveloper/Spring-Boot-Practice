const { createContext } = require("react");

const userContext=createContext(null)

export default userContext