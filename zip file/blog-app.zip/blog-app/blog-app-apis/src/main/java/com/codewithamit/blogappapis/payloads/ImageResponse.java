package com.codewithamit.blogappapis.payloads;

public class ImageResponse {
    
}
