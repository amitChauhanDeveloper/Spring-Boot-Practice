package com.example.student.student_demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.student.student_demo.model.Strength;

public interface StrengthRepository extends JpaRepository<Strength,Integer>{

    
}
