package com.chat.app.chatroomapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatroomappApplicationTests {

	@Test
	void contextLoads() {
	}

}
