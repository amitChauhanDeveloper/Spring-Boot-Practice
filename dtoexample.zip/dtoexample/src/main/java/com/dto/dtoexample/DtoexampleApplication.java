package com.dto.dtoexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DtoexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DtoexampleApplication.class, args);
	}

}
